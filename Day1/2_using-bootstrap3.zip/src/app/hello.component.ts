import { Component } from "@angular/core";

@Component({
    selector: 'hello',
    template: `
        <h1 class="text-danger">Hello World - Using Bootstrap 3!</h1>
    `
})
export class HelloComponent {

}